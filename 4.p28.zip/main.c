/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#define SIZE 5
void modifyArray(int b[],int size);
void modifyElement(int e);

int main(void)
{
    int a[SIZE]= {0,1,2,3,4};
    int i;
    printf("Effect of passing entire array by reference:\n\nThe"
    "values of the original array are:\n");
    for(i=0;i<SIZE;i++)
    {
        printf("%3d",a[i]);
    }
    printf("\n");
    
    modifyArray(a, SIZE);
    printf("The values of the modified array are:\n");
    for(i=0;i<SIZE;i++)
    {
        printf("%3d",a[i]);
    }
    printf("\n\n\nEffects of passing array element"
    "by value:\n\nThe value of a[3] is %d\n",a[3]);
    modifyElement(a[3]);
    printf("The valuee of a[3] is %d\n" ,a[3]);
    return 0;
}
