/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/

#include <stdio.h>
#include <stdlib.h>

int main (void)
{
    char string1[20];
    char string2[]="string literal";
    int i;
    printf("Enter a string: ");
    scanf("%s",string1);
    getchar();
    printf("string1 is: %s\nstring2 is: %s\n"
    "string1 with spaces between characters is: \n",string1,string2);
    for(i=0;string1[i] !='\0';i++)
        printf("%c ",string1[i]);
    printf("\n");

    return 0;
}
