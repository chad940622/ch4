/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

#define SIZE 12
int main(void)
{
int a[SIZE]={1,3,5,4,7,2,99,16,45,67,89,45};
int i;
int total=0;
for (i=0;i<SIZE; i++)
total+=a[i];
printf( "Total of array element values is %d\n", total);
return 0;
}