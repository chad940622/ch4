/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void inverse(int*);
int main()
{
    int a[3]={3,5,7},i;
    for(i=0;i<3;i++)
        {
            printf("%d  ",a[i]);
        }
    printf("\n");
   inverse(a);
   for(i=0;i<3;i++)
        {
            printf("%d  ",a[i]);
        }
    printf("\n");
   

    return 0;
}
void inverse(int *b)
{
    int tmp[3],i;
    for(i=0;i<3;i++)
        tmp[2-i]=b[i];
    for(i=0;i<3;i++)
        b[i]=tmp[i];
        
}
