/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/

#include <stdio.h>
#define SIZE 10 


void bubbleSort(int * const array, const int size); 
void printArray(const int *array, const int size); 

int main(void)
{
    int a[SIZE] = {2, 6, 4, 8, 10, 12, 89, 68, 45, 37};

    printf("Data items in original order\n");
    printArray(a, SIZE); 

    bubbleSort(a, SIZE); 

    printf("\nData items in ascending order\n");
    printArray(a, SIZE); 

    return 0; 
} 
void bubbleSort(int * const array, const int size)
{
    void swap(int *element1Ptr, int *element2Ptr); 
    int pass; 
    int comparison; 
    int swapped; 
    for (pass = 0; pass < size - 1; pass++)
    {
        swapped = 0; 
        for (comparison = 0; comparison < size - 1 - pass; comparison++)
        {
            if (array[comparison] > array[comparison + 1])
            {
                swap(&array[comparison], &array[comparison + 1]);
                swapped = 1; 
            }
        } 

       
        if (swapped == 0)
        {
            break; 
        } 
    } 
} 

void swap(int *element1Ptr, int *element2Ptr)
{
    int hold = *element1Ptr; 
    *element1Ptr = *element2Ptr;
    *element2Ptr = hold;
} 
void printArray(const int *array, const int size)
{
    int i; 
    for (i = 0; i < size; i++)
    {
        printf("%d ", array[i]);
    } 

    printf("\n"); 
} 