/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>
#include <stdlib.h>
void staticArrayInit(void);
void automaticArrayInit(void);

int main(void)
{
    printf("Frist call to each function:\n");
    staticArrayInit();
    automaticArrayInit();
    printf("\n\nSecond call to each function:\n");
    staticArrayInit();
    automaticArrayInit();
    printf("\n");
    return 0;
}
void staticArrayInit(void)
{
    static int array1[3];
    int i;
    printf("\nValues on entering staticArrayInit:\n");
    for(i=0;i<=2;i++)
        {
            printf("array1[%d] = %d ",i,array1[i]);
        }
    printf("\nValues on exiting staticArrayInit:\n");
    for(i=0;i<=2;i++)
        printf("array1[%d] = %d ",i,array1[i]+=5);
}
void automaticArrayInit(void)
{
    
    static int array2[3]={1,2,3};
    int i;
    printf("\n\nValues on entering staticArrayInit:\n");
    for(i=0;i<=2;i++)
        {
            printf("array2[%d] = %d ",i,array2[i]);
        }
    printf("\nValues on exiting staticArrayInit:\n");
    for(i=0;i<=2;i++)
        printf("array2[%d] = %d ",i,array2[i]+=5);
    
}

